//% weight=90 color=#ff6600 icon="\uf185"
namespace B4B_Weather {

    let clkPin: DigitalPin
    let dioPin: DigitalPin

    /**
     * Initialize 4-digit 7-seg TM1637 display
     * @param clk clock pin
     * @param dio data pin
     */
    //% block="init 7-seg display CLK %clk DIO %dio"
    export function initDisplay(clk: DigitalPin, dio: DigitalPin): void {
        clkPin = clk
        dioPin = dio
        tm1637Init()
    }

    /**
     * Show number on 7-seg display
     * @param value number to display (-999 to 9999)
     */
    //% block="show number %value on 7-seg"
    export function showNumber(value: number): void {
        tm1637ShowNumber(value)
    }

    /**
     * Show sensor value on 7-seg display
     * @param sensor select sensor to display
     */
    //% block="show %sensor on 7-seg"
    export function showSensor(sensor: SensorType): void {
        let v = 0
        if (sensor == SensorType.Soil) v = soilMoisture()
        else if (sensor == SensorType.Light) v = lightLevel()
        else if (sensor == SensorType.Temp) v = readDHT11(0)
        else if (sensor == SensorType.Humidity) v = readDHT11(1)
        else if (sensor == SensorType.BMPTemp) v = bmpTemperature()
        showNumber(v)
    }

    /**
     * Cycle through all sensors and display each for 2 seconds
     */
    //% block="cycle all sensor values on 7-seg"
    export function cycleSensors(): void {
        while (true) {
            showSensor(SensorType.Temp)
            basic.pause(2000)
            showSensor(SensorType.Humidity)
            basic.pause(2000)
            showSensor(SensorType.Soil)
            basic.pause(2000)
            showSensor(SensorType.Light)
            basic.pause(2000)
        }
    }

    /**
     * Sensor type dropdown
     */
    export enum SensorType {
        //% block="soil moisture"
        Soil,
        //% block="light level"
        Light,
        //% block="temperature (DHT11)"
        Temp,
        //% block="humidity (DHT11)"
        Humidity,
        //% block="BMP280 temperature"
        BMPTemp
    }

    // ===== Minimal TM1637 placeholder driver =====
    function tm1637Init() {
        // TODO: Implement TM1637 init sequence
    }

    function tm1637ShowNumber(num: number) {
        // TODO: Implement TM1637 display
        // For now, show on micro:bit LEDs as fallback
        basic.showNumber(num)
    }

    // ===== Placeholder sensor functions =====
    function soilMoisture(): number {
        return pins.analogReadPin(AnalogPin.P1)
    }

    function lightLevel(): number {
        return input.lightLevel()
    }

    function readDHT11(mode: number): number {
        // Placeholder: replace with actual DHT11 code
        if (mode == 0) return 23 // temp
        return 45 // humidity
    }

    function bmpTemperature(): number {
        // Placeholder: replace with actual BMP280 driver
        return 22
    }
}